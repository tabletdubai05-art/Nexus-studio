package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.nexus.data.ProjectRepository
import com.example.nexus.model.AspectRatio
import com.example.nexus.model.ClipType
import com.example.nexus.model.TrackType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("NEXUS Studio", appName)
    }

    @Test
    fun `project repository creates starter project and saves cleanly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = ProjectRepository(context)
        val starter = repository.createSampleStarterProject()

        assertNotNull(starter)
        assertTrue(starter.clips.isNotEmpty())
        assertEquals(AspectRatio.VERTICAL_9_16, starter.config.aspectRatio)

        val videoClips = starter.clips.filter { it.trackType == TrackType.VIDEO }
        assertTrue(videoClips.isNotEmpty())

        val saveSuccess = repository.saveProject(starter)
        assertTrue(saveSuccess)

        val retrieved = repository.getProjectById(starter.id)
        assertNotNull(retrieved)
        assertEquals(starter.name, retrieved?.name)
        assertEquals(starter.clips.size, retrieved?.clips?.size)
    }
}
