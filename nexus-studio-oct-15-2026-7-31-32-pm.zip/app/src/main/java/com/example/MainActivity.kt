package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.nexus.ui.screens.EditorMainScreen
import com.example.nexus.viewmodel.EditorViewModel
import com.example.ui.theme.NexusDarkBg
import com.example.ui.theme.NexusStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NexusStudioTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = NexusDarkBg
                ) {
                    val viewModel: EditorViewModel = viewModel()
                    EditorMainScreen(viewModel = viewModel)
                }
            }
        }
    }
}
