package com.example.nexus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.rememberScrollableState
import androidx.compose.foundation.gestures.scrollable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexus.model.*
import com.example.nexus.player.PlaybackController
import com.example.ui.theme.*

@Composable
fun TimelineView(
    project: Project,
    currentPositionMs: Long,
    selectedClipId: String?,
    timelineZoom: Float,
    isSnapEnabled: Boolean,
    onSelectClip: (String?) -> Unit,
    onSeekTo: (Long) -> Unit,
    onUpdateClipTrim: (String, Long, Long) -> Unit,
    onUpdateClipStart: (String, Long) -> Unit,
    onSplitClip: () -> Unit,
    onDuplicateClip: () -> Unit,
    onDeleteClip: () -> Unit,
    onAddTextLayer: () -> Unit,
    onAddSticker: () -> Unit,
    onImportMediaClick: () -> Unit,
    onToggleSnap: () -> Unit,
    onZoomChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    // 1 second in px at 1.0x zoom = 60 dp
    val basePxPerSecond = 65f * timelineZoom
    val msToDp = basePxPerSecond / 1000f

    val totalDurationMs = project.totalDurationMs.coerceAtLeast(10000L)
    val timelineWidthDp = (totalDurationMs * msToDp).dp + 200.dp

    val horizontalScrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(NexusSurface)
            .border(1.dp, NexusBorder, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .padding(top = 8.dp)
    ) {
        // Timeline Action Bar (Split, Duplicate, Delete, Add Text, Add Overlay, Snap, Zoom)
        TimelineToolbar(
            selectedClip = project.clips.find { it.id == selectedClipId },
            isSnapEnabled = isSnapEnabled,
            timelineZoom = timelineZoom,
            onSplitClip = onSplitClip,
            onDuplicateClip = onDuplicateClip,
            onDeleteClip = onDeleteClip,
            onAddTextLayer = onAddTextLayer,
            onAddSticker = onAddSticker,
            onImportMediaClick = onImportMediaClick,
            onToggleSnap = onToggleSnap,
            onZoomChange = onZoomChange
        )

        Divider(color = NexusBorder, thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

        // Tracks and Playhead container (Horizontally scrollable)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .horizontalScroll(horizontalScrollState)
                .pointerInput(totalDurationMs) {
                    detectDragGestures { change, _ ->
                        change.consume()
                        val tappedTimeMs = (change.position.x / msToDp).toLong().coerceIn(0L, totalDurationMs)
                        onSeekTo(tappedTimeMs)
                    }
                }
                .testTag("timeline_tracks_area")
        ) {
            Column(
                modifier = Modifier
                    .width(timelineWidthDp)
                    .fillMaxHeight()
                    .padding(horizontal = 24.dp)
            ) {
                // Timecode Ruler
                TimelineRuler(
                    totalDurationMs = totalDurationMs,
                    msToDp = msToDp
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Text Track Lane
                TrackLane(
                    trackType = TrackType.TEXT,
                    trackTitle = "TEXTO",
                    trackColor = NexusTrackText,
                    clips = project.clips.filter { it.trackType == TrackType.TEXT },
                    selectedClipId = selectedClipId,
                    msToDp = msToDp,
                    onSelectClip = onSelectClip,
                    onUpdateClipTrim = onUpdateClipTrim,
                    onUpdateClipStart = onUpdateClipStart
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Overlay / Sticker Track Lane
                TrackLane(
                    trackType = TrackType.OVERLAY,
                    trackTitle = "CAMADAS",
                    trackColor = NexusTrackOverlay,
                    clips = project.clips.filter { it.trackType == TrackType.OVERLAY },
                    selectedClipId = selectedClipId,
                    msToDp = msToDp,
                    onSelectClip = onSelectClip,
                    onUpdateClipTrim = onUpdateClipTrim,
                    onUpdateClipStart = onUpdateClipStart
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Video Track Lane (Primary)
                TrackLane(
                    trackType = TrackType.VIDEO,
                    trackTitle = "VÍDEO",
                    trackColor = NexusTrackVideo,
                    clips = project.clips.filter { it.trackType == TrackType.VIDEO },
                    selectedClipId = selectedClipId,
                    msToDp = msToDp,
                    onSelectClip = onSelectClip,
                    onUpdateClipTrim = onUpdateClipTrim,
                    onUpdateClipStart = onUpdateClipStart
                )
            }

            // Red/Cyan Playhead Vertical Line with scrubbing head
            val playheadOffsetDp = 24.dp + (currentPositionMs * msToDp).dp
            Box(
                modifier = Modifier
                    .offset(x = playheadOffsetDp - 1.dp)
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(NexusCyanGlow)
            )

            // Playhead Grab Handle (Top triangle / diamond)
            Box(
                modifier = Modifier
                    .offset(x = playheadOffsetDp - 7.dp, y = 2.dp)
                    .size(14.dp)
                    .background(NexusCyanGlow, CircleShape)
                    .border(1.5.dp, Color.White, CircleShape)
            )
        }
    }
}

@Composable
fun TimelineToolbar(
    selectedClip: Clip?,
    isSnapEnabled: Boolean,
    timelineZoom: Float,
    onSplitClip: () -> Unit,
    onDuplicateClip: () -> Unit,
    onDeleteClip: () -> Unit,
    onAddTextLayer: () -> Unit,
    onAddSticker: () -> Unit,
    onImportMediaClick: () -> Unit,
    onToggleSnap: () -> Unit,
    onZoomChange: (Float) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left actions: Split, Duplicate, Delete
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Split (Dividir)
            FilledTonalIconButton(
                onClick = onSplitClip,
                enabled = selectedClip != null,
                colors = IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = NexusSurfaceCard,
                    contentColor = NexusCyanLight
                ),
                modifier = Modifier
                    .size(38.dp)
                    .testTag("split_clip_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCut,
                    contentDescription = "Dividir Clipe",
                    modifier = Modifier.size(18.dp)
                )
            }

            // Duplicate
            FilledTonalIconButton(
                onClick = onDuplicateClip,
                enabled = selectedClip != null,
                colors = IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = NexusSurfaceCard,
                    contentColor = NexusElectricPurpleLight
                ),
                modifier = Modifier
                    .size(38.dp)
                    .testTag("duplicate_clip_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Duplicar Clipe",
                    modifier = Modifier.size(18.dp)
                )
            }

            // Delete
            FilledTonalIconButton(
                onClick = onDeleteClip,
                enabled = selectedClip != null,
                colors = IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = NexusSurfaceCard,
                    contentColor = NexusRedCut
                ),
                modifier = Modifier
                    .size(38.dp)
                    .testTag("delete_clip_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Excluir Clipe",
                    modifier = Modifier.size(18.dp)
                )
            }

            // Snap Magnetic Toggle
            IconButton(
                onClick = onToggleSnap,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("snap_toggle_button")
            ) {
                Icon(
                    imageVector = if (isSnapEnabled) Icons.Default.VerticalAlignBottom else Icons.Default.VerticalAlignTop,
                    contentDescription = "Snap Magnético",
                    tint = if (isSnapEnabled) NexusCyanLight else NexusTextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // Center / Right actions: Add items and Zoom
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Add Media
            Button(
                onClick = onImportMediaClick,
                colors = ButtonDefaults.buttonColors(containerColor = NexusElectricPurple),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(34.dp)
                    .testTag("import_media_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Mídia",
                    modifier = Modifier.size(16.dp),
                    tint = Color.White
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Mídia", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }

            // Add Text
            FilledTonalButton(
                onClick = onAddTextLayer,
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = NexusSurfaceCard,
                    contentColor = NexusCyanLight
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(34.dp)
                    .testTag("add_text_button")
            ) {
                Icon(
                    imageVector = Icons.Default.TextFields,
                    contentDescription = "Texto",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Texto", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }

            // Add Overlay
            FilledTonalButton(
                onClick = onAddSticker,
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = NexusSurfaceCard,
                    contentColor = NexusTrackOverlay
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(34.dp)
                    .testTag("add_overlay_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Layers,
                    contentDescription = "Camada",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Camada", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }

            // Zoom In/Out
            IconButton(
                onClick = { onZoomChange((timelineZoom - 0.2f).coerceAtLeast(0.5f)) },
                modifier = Modifier.size(34.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ZoomOut,
                    contentDescription = "Zoom Out",
                    tint = NexusTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }

            IconButton(
                onClick = { onZoomChange((timelineZoom + 0.2f).coerceAtMost(2.5f)) },
                modifier = Modifier.size(34.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ZoomIn,
                    contentDescription = "Zoom In",
                    tint = NexusTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun TimelineRuler(
    totalDurationMs: Long,
    msToDp: Float
) {
    val durationSeconds = (totalDurationMs / 1000).toInt() + 2

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(20.dp)
    ) {
        for (sec in 0..durationSeconds) {
            val offsetDp = (sec * 1000L * msToDp).dp
            val isMajor = sec % 5 == 0

            Row(
                modifier = Modifier.offset(x = offsetDp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(if (isMajor) 14.dp else 8.dp)
                        .background(if (isMajor) NexusTextSecondary else NexusBorderHighlight)
                )
                if (isMajor) {
                    Text(
                        text = "${sec}s",
                        color = NexusTextSecondary,
                        fontSize = 9.sp,
                        modifier = Modifier.padding(start = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun TrackLane(
    trackType: TrackType,
    trackTitle: String,
    trackColor: Color,
    clips: List<Clip>,
    selectedClipId: String?,
    msToDp: Float,
    onSelectClip: (String?) -> Unit,
    onUpdateClipTrim: (String, Long, Long) -> Unit,
    onUpdateClipStart: (String, Long) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .background(NexusSurfaceTrack, RoundedCornerShape(6.dp))
            .border(0.5.dp, NexusBorder, RoundedCornerShape(6.dp))
    ) {
        // Clips on this track
        clips.forEach { clip ->
            val isSelected = clip.id == selectedClipId
            val clipStartDp = (clip.timelineStartMs * msToDp).dp
            val clipWidthDp = (clip.durationMs * msToDp).dp.coerceAtLeast(36.dp)

            Box(
                modifier = Modifier
                    .offset(x = clipStartDp)
                    .width(clipWidthDp)
                    .fillMaxHeight()
                    .padding(vertical = 2.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color(clip.colorBadgeHex),
                                Color(clip.colorBadgeHex).copy(alpha = 0.75f)
                            )
                        )
                    )
                    .border(
                        width = if (isSelected) 2.dp else 0.5.dp,
                        color = if (isSelected) NexusCyanGlow else Color.White.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(6.dp)
                    )
                    .clickable { onSelectClip(clip.id) }
                    .pointerInput(clip.id) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val deltaMs = (dragAmount.x / msToDp).toLong()
                            val newStart = (clip.timelineStartMs + deltaMs).coerceAtLeast(0L)
                            onUpdateClipStart(clip.id, newStart)
                        }
                    }
                    .testTag("clip_block_${clip.id}")
            ) {
                // Clip content info (Title and duration)
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = clip.title,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "${(clip.durationMs / 1000f).let { String.format("%.1fs", it) }}",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Trim Handles (Visible when selected)
                if (isSelected) {
                    // Left Trim Handle (Source In)
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .width(14.dp)
                            .fillMaxHeight()
                            .background(NexusCyanGlow)
                            .pointerInput(clip.id) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    val deltaMs = (dragAmount.x / msToDp).toLong()
                                    val newSourceIn = (clip.sourceInMs + deltaMs).coerceIn(0L, clip.sourceOutMs - 200L)
                                    val newStart = (clip.timelineStartMs + deltaMs).coerceAtLeast(0L)
                                    onUpdateClipTrim(clip.id, newSourceIn, clip.sourceOutMs)
                                    onUpdateClipStart(clip.id, newStart)
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DragHandle,
                            contentDescription = "Trim In",
                            tint = Color.Black,
                            modifier = Modifier.size(10.dp)
                        )
                    }

                    // Right Trim Handle (Source Out)
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .width(14.dp)
                            .fillMaxHeight()
                            .background(NexusCyanGlow)
                            .pointerInput(clip.id) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    val deltaMs = (dragAmount.x / msToDp).toLong()
                                    val newSourceOut = (clip.sourceOutMs + deltaMs).coerceAtLeast(clip.sourceInMs + 200L)
                                    onUpdateClipTrim(clip.id, clip.sourceInMs, newSourceOut)
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DragHandle,
                            contentDescription = "Trim Out",
                            tint = Color.Black,
                            modifier = Modifier.size(10.dp)
                        )
                    }
                }
            }
        }
    }
}
