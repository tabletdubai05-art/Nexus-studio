package com.example.nexus.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.nexus.data.ProjectRepository
import com.example.nexus.export.ExportEngine
import com.example.nexus.export.ExportState
import com.example.nexus.model.*
import com.example.nexus.player.PlaybackController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class InspectorTab {
    TRANSFORM,
    TEXT,
    AUDIO,
    TIMING
}

enum class ActiveScreen {
    HOME,
    EDITOR,
    EXPORT_MODAL
}

class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ProjectRepository(application)
    val playbackController = PlaybackController(application)
    val exportEngine = ExportEngine(application)

    private val _activeScreen = MutableStateFlow(ActiveScreen.HOME)
    val activeScreen: StateFlow<ActiveScreen> = _activeScreen.asStateFlow()

    private val _projectsList = MutableStateFlow<List<Project>>(emptyList())
    val projectsList: StateFlow<List<Project>> = _projectsList.asStateFlow()

    private val _currentProject = MutableStateFlow(repository.createSampleStarterProject())
    val currentProject: StateFlow<Project> = _currentProject.asStateFlow()

    private val _selectedClipId = MutableStateFlow<String?>("sample_text_1")
    val selectedClipId: StateFlow<String?> = _selectedClipId.asStateFlow()

    val currentPositionMs = playbackController.currentPositionMs
    val isPlaying = playbackController.isPlaying
    val exportState: StateFlow<ExportState> = exportEngine.exportState

    private val _timelineZoom = MutableStateFlow(1.0f) // 0.5f to 3.0f
    val timelineZoom: StateFlow<Float> = _timelineZoom.asStateFlow()

    private val _isSnapEnabled = MutableStateFlow(true)
    val isSnapEnabled: StateFlow<Boolean> = _isSnapEnabled.asStateFlow()

    private val _activeInspectorTab = MutableStateFlow(InspectorTab.TRANSFORM)
    val activeInspectorTab: StateFlow<InspectorTab> = _activeInspectorTab.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>("Bem-vindo ao NEXUS Studio v0.1")
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    init {
        playbackController.setScope(viewModelScope)
        loadProjects()
    }

    fun loadProjects() {
        viewModelScope.launch {
            val list = repository.getAllProjects()
            _projectsList.value = list
            if (list.isNotEmpty() && _currentProject.value.id == "project_nexus_demo") {
                _currentProject.value = list.first()
            }
        }
    }

    fun openHomeScreen() {
        playbackController.pause()
        loadProjects()
        _activeScreen.value = ActiveScreen.HOME
    }

    // Alias for backward compatibility
    fun openProjectsScreen() {
        openHomeScreen()
    }

    fun returnToEditor() {
        _activeScreen.value = ActiveScreen.EDITOR
    }

    fun openExportModal() {
        playbackController.pause()
        exportEngine.resetState()
        _activeScreen.value = ActiveScreen.EXPORT_MODAL
    }

    fun dismissExportModal() {
        _activeScreen.value = ActiveScreen.EDITOR
    }

    fun duplicateProject(project: Project) {
        val clonedClips = project.clips.map { clip ->
            clip.copy(id = UUID.randomUUID().toString())
        }
        val duplicated = project.copy(
            id = UUID.randomUUID().toString(),
            name = "${project.name} (Cópia)",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            clips = clonedClips
        )
        repository.saveProject(duplicated)
        loadProjects()
        showFeedback("Projeto duplicado com sucesso")
    }

    fun loadDemoProject() {
        val demo = repository.createSampleStarterProject()
        repository.saveProject(demo)
        openProject(demo)
        showFeedback("Projeto Demo NEXUS carregado!")
    }

    fun createNewProject(name: String, aspectRatio: AspectRatio) {
        val newProj = Project(
            id = UUID.randomUUID().toString(),
            name = if (name.isBlank()) "Projeto Sem Título" else name,
            config = ProjectConfig(aspectRatio = aspectRatio),
            clips = emptyList()
        )
        repository.saveProject(newProj)
        _currentProject.value = newProj
        _selectedClipId.value = null
        playbackController.seekTo(0L)
        loadProjects()
        _activeScreen.value = ActiveScreen.EDITOR
        showFeedback("Projeto criado com proporção ${aspectRatio.label}")
    }

    fun openProject(project: Project) {
        playbackController.pause()
        _currentProject.value = project
        _selectedClipId.value = project.clips.firstOrNull()?.id
        playbackController.seekTo(0L)
        _activeScreen.value = ActiveScreen.EDITOR
        showFeedback("Projeto '${project.name}' carregado")
    }

    fun saveCurrentProject() {
        val success = repository.saveProject(_currentProject.value)
        if (success) {
            showFeedback("Projeto salvo com sucesso!")
            loadProjects()
        } else {
            showFeedback("Erro ao salvar projeto.")
        }
    }

    fun deleteProject(project: Project) {
        repository.deleteProject(project.id)
        loadProjects()
        if (_currentProject.value.id == project.id) {
            val remaining = _projectsList.value.filter { it.id != project.id }
            if (remaining.isNotEmpty()) {
                openProject(remaining.first())
            } else {
                createNewProject("Novo Projeto", AspectRatio.VERTICAL_9_16)
            }
        }
        showFeedback("Projeto '${project.name}' excluído")
    }

    fun selectClip(clipId: String?) {
        _selectedClipId.value = clipId
        val clip = _currentProject.value.clips.find { it.id == clipId }
        if (clip != null) {
            if (clip.type == ClipType.TEXT) {
                _activeInspectorTab.value = InspectorTab.TEXT
            } else {
                _activeInspectorTab.value = InspectorTab.TRANSFORM
            }
        }
    }

    fun setInspectorTab(tab: InspectorTab) {
        _activeInspectorTab.value = tab
    }

    fun setTimelineZoom(zoom: Float) {
        _timelineZoom.value = zoom.coerceIn(0.4f, 3.5f)
    }

    fun toggleSnap() {
        _isSnapEnabled.value = !_isSnapEnabled.value
        showFeedback(if (_isSnapEnabled.value) "Snap magnético ativado" else "Snap desativado")
    }

    fun importMedia(uri: Uri, isVideo: Boolean) {
        viewModelScope.launch {
            val item = repository.importMediaFile(uri, isVideo)
            if (item != null) {
                val updatedLibrary = _currentProject.value.mediaLibrary + item
                val updatedProject = _currentProject.value.copy(mediaLibrary = updatedLibrary)
                _currentProject.value = updatedProject
                repository.saveProject(updatedProject)

                // Auto-add clip to appropriate track on timeline
                val track = if (isVideo) TrackType.VIDEO else TrackType.OVERLAY
                addClipFromMedia(item, track)
                showFeedback("Mídia importada: ${item.name}")
            } else {
                showFeedback("Falha ao importar arquivo de mídia")
            }
        }
    }

    fun addClipFromMedia(mediaItem: MediaItem, trackType: TrackType) {
        val currentClips = _currentProject.value.clips
        val lastClipOnTrack = currentClips.filter { it.trackType == trackType }.maxByOrNull { it.timelineEndMs }
        val startMs = lastClipOnTrack?.timelineEndMs ?: currentPositionMs.value

        val newClip = Clip(
            id = UUID.randomUUID().toString(),
            mediaId = mediaItem.id,
            mediaUri = mediaItem.uriString,
            type = mediaItem.type,
            trackType = trackType,
            title = mediaItem.name.take(16),
            timelineStartMs = startMs,
            sourceInMs = 0L,
            sourceOutMs = mediaItem.durationMs.coerceAtMost(6000L),
            colorBadgeHex = if (trackType == TrackType.VIDEO) 0xFF7C3AED else 0xFF059669
        )

        val updated = _currentProject.value.copy(clips = currentClips + newClip)
        _currentProject.value = updated
        _selectedClipId.value = newClip.id
        saveCurrentProject()
    }

    fun addTextLayer() {
        val currentClips = _currentProject.value.clips
        val startMs = currentPositionMs.value

        val newClip = Clip(
            id = UUID.randomUUID().toString(),
            type = ClipType.TEXT,
            trackType = TrackType.TEXT,
            title = "Texto",
            timelineStartMs = startMs,
            sourceInMs = 0L,
            sourceOutMs = 3500L,
            textProperties = TextProperties(
                text = "NOVO TÍTULO",
                textColorHex = 0xFF00F0FF,
                fontSizeSp = 24f,
                backgroundColorHex = 0xAA000000,
                hasBackgroundPill = true
            ),
            transform = TransformProperties(positionY = -15f),
            colorBadgeHex = 0xFF06B6D4
        )

        val updated = _currentProject.value.copy(clips = currentClips + newClip)
        _currentProject.value = updated
        _selectedClipId.value = newClip.id
        _activeInspectorTab.value = InspectorTab.TEXT
        saveCurrentProject()
        showFeedback("Camada de texto adicionada")
    }

    fun addStickerOverlay(title: String, colorHex: Long) {
        val currentClips = _currentProject.value.clips
        val startMs = currentPositionMs.value

        val newClip = Clip(
            id = UUID.randomUUID().toString(),
            type = ClipType.IMAGE,
            trackType = TrackType.OVERLAY,
            title = title,
            timelineStartMs = startMs,
            sourceInMs = 0L,
            sourceOutMs = 4000L,
            transform = TransformProperties(
                scale = 0.8f,
                positionX = 0f,
                positionY = 0f
            ),
            colorBadgeHex = colorHex
        )

        val updated = _currentProject.value.copy(clips = currentClips + newClip)
        _currentProject.value = updated
        _selectedClipId.value = newClip.id
        _activeInspectorTab.value = InspectorTab.TRANSFORM
        saveCurrentProject()
        showFeedback("Camada gráfica '$title' adicionada")
    }

    fun splitClipAtPlayhead() {
        val selectedId = _selectedClipId.value ?: return
        val currentClips = _currentProject.value.clips.toMutableList()
        val index = currentClips.indexOfFirst { it.id == selectedId }
        if (index == -1) return

        val clip = currentClips[index]
        val playhead = currentPositionMs.value

        if (playhead <= clip.timelineStartMs + 200L || playhead >= clip.timelineEndMs - 200L) {
            showFeedback("Posicione a agulha dentro do clipe para dividir")
            return
        }

        val splitOffset = playhead - clip.timelineStartMs
        val originalSourceOut = clip.sourceOutMs
        val splitSourceTime = clip.sourceInMs + splitOffset

        // First part of the clip
        val firstClip = clip.copy(
            sourceOutMs = splitSourceTime
        )

        // Second part of the clip
        val secondClip = clip.copy(
            id = UUID.randomUUID().toString(),
            timelineStartMs = playhead,
            sourceInMs = splitSourceTime,
            sourceOutMs = originalSourceOut,
            title = "${clip.title} (2)"
        )

        currentClips[index] = firstClip
        currentClips.add(index + 1, secondClip)

        val updated = _currentProject.value.copy(clips = currentClips)
        _currentProject.value = updated
        _selectedClipId.value = secondClip.id
        saveCurrentProject()
        showFeedback("Clipe dividido no playhead (corte realizado)")
    }

    fun duplicateSelectedClip() {
        val selectedId = _selectedClipId.value ?: return
        val currentClips = _currentProject.value.clips.toMutableList()
        val clip = currentClips.find { it.id == selectedId } ?: return

        val clonedClip = clip.copy(
            id = UUID.randomUUID().toString(),
            timelineStartMs = clip.timelineEndMs + 100L,
            title = "${clip.title} (Cópia)"
        )

        currentClips.add(clonedClip)
        val updated = _currentProject.value.copy(clips = currentClips)
        _currentProject.value = updated
        _selectedClipId.value = clonedClip.id
        saveCurrentProject()
        showFeedback("Clipe duplicado")
    }

    fun deleteSelectedClip() {
        val selectedId = _selectedClipId.value ?: return
        val currentClips = _currentProject.value.clips.filter { it.id != selectedId }
        val updated = _currentProject.value.copy(clips = currentClips)
        _currentProject.value = updated
        _selectedClipId.value = currentClips.firstOrNull()?.id
        saveCurrentProject()
        showFeedback("Clipe removido")
    }

    fun updateClipTrim(clipId: String, newSourceInMs: Long, newSourceOutMs: Long) {
        val currentClips = _currentProject.value.clips.map { clip ->
            if (clip.id == clipId) {
                clip.copy(
                    sourceInMs = newSourceInMs.coerceAtLeast(0L),
                    sourceOutMs = newSourceOutMs.coerceAtLeast(newSourceInMs + 100L)
                )
            } else clip
        }
        _currentProject.value = _currentProject.value.copy(clips = currentClips)
    }

    fun updateClipTimelineStart(clipId: String, newStartMs: Long) {
        var snappedStart = newStartMs.coerceAtLeast(0L)
        if (_isSnapEnabled.value) {
            val otherClips = _currentProject.value.clips.filter { it.id != clipId }
            for (other in otherClips) {
                if (Math.abs(snappedStart - other.timelineEndMs) < 150L) {
                    snappedStart = other.timelineEndMs
                    break
                }
                if (Math.abs(snappedStart - other.timelineStartMs) < 150L) {
                    snappedStart = other.timelineStartMs
                    break
                }
            }
        }

        val currentClips = _currentProject.value.clips.map { clip ->
            if (clip.id == clipId) {
                clip.copy(timelineStartMs = snappedStart)
            } else clip
        }
        _currentProject.value = _currentProject.value.copy(clips = currentClips)
    }

    fun updateTransform(clipId: String, transform: TransformProperties) {
        val currentClips = _currentProject.value.clips.map { clip ->
            if (clip.id == clipId) {
                clip.copy(transform = transform)
            } else clip
        }
        _currentProject.value = _currentProject.value.copy(clips = currentClips)
    }

    fun updateTextProperties(clipId: String, textProps: TextProperties) {
        val currentClips = _currentProject.value.clips.map { clip ->
            if (clip.id == clipId) {
                clip.copy(textProperties = textProps)
            } else clip
        }
        _currentProject.value = _currentProject.value.copy(clips = currentClips)
    }

    fun updateVolume(clipId: String, volume: Float, isMuted: Boolean) {
        val currentClips = _currentProject.value.clips.map { clip ->
            if (clip.id == clipId) {
                clip.copy(volume = volume.coerceIn(0f, 2.0f), isMuted = isMuted)
            } else clip
        }
        _currentProject.value = _currentProject.value.copy(clips = currentClips)
    }

    fun togglePlayPause() {
        playbackController.togglePlayPause(_currentProject.value)
    }

    fun seekTo(positionMs: Long) {
        playbackController.seekTo(positionMs)
    }

    fun stepFrame(forward: Boolean) {
        playbackController.stepFrames(if (forward) 1 else -1, _currentProject.value.config.fps)
    }

    fun exportCurrentFrameSnapshot() {
        viewModelScope.launch {
            val path = exportEngine.exportProjectSnapshot(_currentProject.value, currentPositionMs.value)
            if (path != null) {
                showFeedback("Quadro renderizado em 1080p salvo!")
            }
        }
    }

    fun startVideoExport(fps: Int = 30, resolution: ExportResolution = ExportResolution.FHD_1080P) {
        viewModelScope.launch {
            exportEngine.simulateVideoExport(_currentProject.value, fps, resolution)
        }
    }

    fun showFeedback(msg: String) {
        _feedbackMessage.value = msg
    }

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        playbackController.release()
    }
}
