package com.example.nexus.data

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.example.nexus.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class ProjectRepository(private val context: Context) {

    private val projectsDir: File = File(context.filesDir, "nexus_projects").apply {
        if (!exists()) mkdirs()
    }

    private val mediaCacheDir: File = File(context.filesDir, "nexus_media").apply {
        if (!exists()) mkdirs()
    }

    fun getAllProjects(): List<Project> {
        val files = projectsDir.listFiles { _, name -> name.endsWith(".nexus.json") } ?: emptyArray()
        val list = mutableListOf<Project>()
        for (file in files) {
            try {
                val jsonString = file.readText()
                val project = deserializeProject(jsonString)
                list.add(project)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return if (list.isEmpty()) {
            val starter = createSampleStarterProject()
            saveProject(starter)
            listOf(starter)
        } else {
            list.sortedByDescending { it.updatedAt }
        }
    }

    fun getProjectById(id: String): Project? {
        val file = File(projectsDir, "$id.nexus.json")
        if (!file.exists()) return null
        return try {
            deserializeProject(file.readText())
        } catch (e: Exception) {
            null
        }
    }

    fun saveProject(project: Project): Boolean {
        return try {
            val updated = project.copy(updatedAt = System.currentTimeMillis())
            val jsonString = serializeProject(updated)
            val file = File(projectsDir, "${project.id}.nexus.json")
            file.writeText(jsonString)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun deleteProject(id: String): Boolean {
        val file = File(projectsDir, "$id.nexus.json")
        return file.exists() && file.delete()
    }

    fun importMediaFile(uri: Uri, isVideo: Boolean): MediaItem? {
        return try {
            val ext = if (isVideo) ".mp4" else ".jpg"
            val targetFile = File(mediaCacheDir, "media_${UUID.randomUUID()}$ext")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }

            var duration = 4000L
            var width = 1080
            var height = 1920

            if (isVideo) {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(targetFile.absolutePath)
                    val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    val wStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                    val hStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                    duration = durStr?.toLongOrNull() ?: 5000L
                    width = wStr?.toIntOrNull() ?: 1080
                    height = hStr?.toIntOrNull() ?: 1920
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    try { retriever.release() } catch (_: Exception) {}
                }
            }

            MediaItem(
                id = UUID.randomUUID().toString(),
                uriString = targetFile.toURI().toString(),
                name = targetFile.name,
                type = if (isVideo) ClipType.VIDEO else ClipType.IMAGE,
                durationMs = duration,
                width = width,
                height = height,
                thumbnailUri = targetFile.toURI().toString()
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun createSampleStarterProject(): Project {
        val clipVideo1 = Clip(
            id = "sample_clip_1",
            type = ClipType.VIDEO,
            trackType = TrackType.VIDEO,
            title = "Abertura Cyberpunk",
            timelineStartMs = 0L,
            sourceInMs = 0L,
            sourceOutMs = 4500L,
            volume = 1.0f,
            colorBadgeHex = 0xFF7C3AED,
            transform = TransformProperties(scale = 1.0f)
        )

        val clipVideo2 = Clip(
            id = "sample_clip_2",
            type = ClipType.VIDEO,
            trackType = TrackType.VIDEO,
            title = "Cena Neon Grid",
            timelineStartMs = 4500L,
            sourceInMs = 0L,
            sourceOutMs = 4500L,
            volume = 0.8f,
            colorBadgeHex = 0xFF2563EB,
            transform = TransformProperties(scale = 1.0f)
        )

        val clipText1 = Clip(
            id = "sample_text_1",
            type = ClipType.TEXT,
            trackType = TrackType.TEXT,
            title = "Título NEXUS",
            timelineStartMs = 500L,
            sourceInMs = 0L,
            sourceOutMs = 4000L,
            textProperties = TextProperties(
                text = "NEXUS STUDIO",
                textColorHex = 0xFF00F0FF,
                fontSizeSp = 30f,
                backgroundColorHex = 0xDD15171E,
                hasBackgroundPill = true,
                isBold = true
            ),
            transform = TransformProperties(
                positionX = 0f,
                positionY = -25f,
                scale = 1.0f,
                opacity = 1.0f
            ),
            colorBadgeHex = 0xFF06B6D4
        )

        val clipText2 = Clip(
            id = "sample_text_2",
            type = ClipType.TEXT,
            trackType = TrackType.TEXT,
            title = "Subtítulo v0.1",
            timelineStartMs = 4800L,
            sourceInMs = 0L,
            sourceOutMs = 3800L,
            textProperties = TextProperties(
                text = "EDIÇÃO PROFISSIONAL MOBILE",
                textColorHex = 0xFFA78BFA,
                fontSizeSp = 18f,
                backgroundColorHex = 0xCC000000,
                hasBackgroundPill = true,
                isBold = true
            ),
            transform = TransformProperties(
                positionX = 0f,
                positionY = 30f,
                scale = 1.0f,
                opacity = 0.95f
            ),
            colorBadgeHex = 0xFFF59E0B
        )

        val clipOverlay = Clip(
            id = "sample_overlay_1",
            type = ClipType.IMAGE,
            trackType = TrackType.OVERLAY,
            title = "Badge Studio 4K",
            timelineStartMs = 1200L,
            sourceInMs = 0L,
            sourceOutMs = 6500L,
            transform = TransformProperties(
                positionX = 35f,
                positionY = -40f,
                scale = 0.65f,
                opacity = 0.9f
            ),
            colorBadgeHex = 0xFF10B981
        )

        return Project(
            id = "project_nexus_demo",
            name = "Demo NEXUS Reel 2026",
            config = ProjectConfig(
                aspectRatio = AspectRatio.VERTICAL_9_16,
                fps = 30,
                resolution = ExportResolution.FHD_1080P
            ),
            clips = listOf(clipVideo1, clipVideo2, clipText1, clipText2, clipOverlay)
        )
    }

    private fun serializeProject(project: Project): String {
        val root = JSONObject().apply {
            put("id", project.id)
            put("name", project.name)
            put("createdAt", project.createdAt)
            put("updatedAt", project.updatedAt)

            val configObj = JSONObject().apply {
                put("aspectRatio", project.config.aspectRatio.name)
                put("fps", project.config.fps)
                put("resolution", project.config.resolution.name)
            }
            put("config", configObj)

            val clipsArr = JSONArray()
            for (clip in project.clips) {
                val clipObj = JSONObject().apply {
                    put("id", clip.id)
                    put("mediaId", clip.mediaId ?: "")
                    put("mediaUri", clip.mediaUri ?: "")
                    put("type", clip.type.name)
                    put("trackType", clip.trackType.name)
                    put("title", clip.title)
                    put("timelineStartMs", clip.timelineStartMs)
                    put("sourceInMs", clip.sourceInMs)
                    put("sourceOutMs", clip.sourceOutMs)
                    put("volume", clip.volume.toDouble())
                    put("isMuted", clip.isMuted)
                    put("colorBadgeHex", clip.colorBadgeHex)

                    val transformObj = JSONObject().apply {
                        put("positionX", clip.transform.positionX.toDouble())
                        put("positionY", clip.transform.positionY.toDouble())
                        put("scale", clip.transform.scale.toDouble())
                        put("rotation", clip.transform.rotation.toDouble())
                        put("opacity", clip.transform.opacity.toDouble())
                        put("isFlippedHorizontal", clip.transform.isFlippedHorizontal)
                        put("isFlippedVertical", clip.transform.isFlippedVertical)
                    }
                    put("transform", transformObj)

                    val textObj = JSONObject().apply {
                        put("text", clip.textProperties.text)
                        put("textColorHex", clip.textProperties.textColorHex)
                        put("fontSizeSp", clip.textProperties.fontSizeSp.toDouble())
                        put("backgroundColorHex", clip.textProperties.backgroundColorHex)
                        put("hasBackgroundPill", clip.textProperties.hasBackgroundPill)
                        put("isBold", clip.textProperties.isBold)
                        put("isItalic", clip.textProperties.isItalic)
                        put("alignment", clip.textProperties.alignment)
                    }
                    put("textProperties", textObj)
                }
                clipsArr.put(clipObj)
            }
            put("clips", clipsArr)

            val mediaArr = JSONArray()
            for (item in project.mediaLibrary) {
                val mObj = JSONObject().apply {
                    put("id", item.id)
                    put("uriString", item.uriString)
                    put("name", item.name)
                    put("type", item.type.name)
                    put("durationMs", item.durationMs)
                    put("width", item.width)
                    put("height", item.height)
                    put("thumbnailUri", item.thumbnailUri ?: "")
                    put("sampleColorHex", item.sampleColorHex)
                }
                mediaArr.put(mObj)
            }
            put("mediaLibrary", mediaArr)
        }
        return root.toString(2)
    }

    private fun deserializeProject(jsonString: String): Project {
        val root = JSONObject(jsonString)
        val id = root.getString("id")
        val name = root.optString("name", "Projeto NEXUS")
        val createdAt = root.optLong("createdAt", System.currentTimeMillis())
        val updatedAt = root.optLong("updatedAt", System.currentTimeMillis())

        val configObj = root.optJSONObject("config")
        val aspectRatioStr = configObj?.optString("aspectRatio", AspectRatio.VERTICAL_9_16.name)
            ?: AspectRatio.VERTICAL_9_16.name
        val aspectRatio = try { AspectRatio.valueOf(aspectRatioStr) } catch (_: Exception) { AspectRatio.VERTICAL_9_16 }
        val fps = configObj?.optInt("fps", 30) ?: 30
        val resStr = configObj?.optString("resolution", ExportResolution.FHD_1080P.name) ?: ExportResolution.FHD_1080P.name
        val resolution = try { ExportResolution.valueOf(resStr) } catch (_: Exception) { ExportResolution.FHD_1080P }

        val config = ProjectConfig(aspectRatio = aspectRatio, fps = fps, resolution = resolution)

        val clips = mutableListOf<Clip>()
        val clipsArr = root.optJSONArray("clips") ?: JSONArray()
        for (i in 0 until clipsArr.length()) {
            val cObj = clipsArr.getJSONObject(i)
            val cId = cObj.getString("id")
            val mediaId = cObj.optString("mediaId").takeIf { it.isNotEmpty() }
            val mediaUri = cObj.optString("mediaUri").takeIf { it.isNotEmpty() }
            val type = try { ClipType.valueOf(cObj.getString("type")) } catch (_: Exception) { ClipType.VIDEO }
            val trackType = try { TrackType.valueOf(cObj.getString("trackType")) } catch (_: Exception) { TrackType.VIDEO }
            val title = cObj.optString("title", "Clip $i")
            val timelineStartMs = cObj.optLong("timelineStartMs", 0L)
            val sourceInMs = cObj.optLong("sourceInMs", 0L)
            val sourceOutMs = cObj.optLong("sourceOutMs", 4000L)
            val volume = cObj.optDouble("volume", 1.0).toFloat()
            val isMuted = cObj.optBoolean("isMuted", false)
            val colorBadgeHex = cObj.optLong("colorBadgeHex", 0xFF7C3AED)

            val tObj = cObj.optJSONObject("transform")
            val transform = if (tObj != null) {
                TransformProperties(
                    positionX = tObj.optDouble("positionX", 0.0).toFloat(),
                    positionY = tObj.optDouble("positionY", 0.0).toFloat(),
                    scale = tObj.optDouble("scale", 1.0).toFloat(),
                    rotation = tObj.optDouble("rotation", 0.0).toFloat(),
                    opacity = tObj.optDouble("opacity", 1.0).toFloat(),
                    isFlippedHorizontal = tObj.optBoolean("isFlippedHorizontal", false),
                    isFlippedVertical = tObj.optBoolean("isFlippedVertical", false)
                )
            } else TransformProperties()

            val textObj = cObj.optJSONObject("textProperties")
            val textProperties = if (textObj != null) {
                TextProperties(
                    text = textObj.optString("text", "NEXUS"),
                    textColorHex = textObj.optLong("textColorHex", 0xFFFFFFFF),
                    fontSizeSp = textObj.optDouble("fontSizeSp", 24.0).toFloat(),
                    backgroundColorHex = textObj.optLong("backgroundColorHex", 0xAA000000),
                    hasBackgroundPill = textObj.optBoolean("hasBackgroundPill", true),
                    isBold = textObj.optBoolean("isBold", true),
                    isItalic = textObj.optBoolean("isItalic", false),
                    alignment = textObj.optInt("alignment", 1)
                )
            } else TextProperties()

            clips.add(
                Clip(
                    id = cId,
                    mediaId = mediaId,
                    mediaUri = mediaUri,
                    type = type,
                    trackType = trackType,
                    title = title,
                    timelineStartMs = timelineStartMs,
                    sourceInMs = sourceInMs,
                    sourceOutMs = sourceOutMs,
                    volume = volume,
                    isMuted = isMuted,
                    transform = transform,
                    textProperties = textProperties,
                    colorBadgeHex = colorBadgeHex
                )
            )
        }

        val mediaLibrary = mutableListOf<MediaItem>()
        val mediaArr = root.optJSONArray("mediaLibrary") ?: JSONArray()
        for (i in 0 until mediaArr.length()) {
            val mObj = mediaArr.getJSONObject(i)
            mediaLibrary.add(
                MediaItem(
                    id = mObj.getString("id"),
                    uriString = mObj.getString("uriString"),
                    name = mObj.getString("name"),
                    type = try { ClipType.valueOf(mObj.getString("type")) } catch (_: Exception) { ClipType.VIDEO },
                    durationMs = mObj.optLong("durationMs", 5000L),
                    width = mObj.optInt("width", 1080),
                    height = mObj.optInt("height", 1920),
                    thumbnailUri = mObj.optString("thumbnailUri").takeIf { it.isNotEmpty() },
                    sampleColorHex = mObj.optLong("sampleColorHex", 0xFF8B5CF6)
                )
            )
        }

        return Project(
            id = id,
            name = name,
            createdAt = createdAt,
            updatedAt = updatedAt,
            config = config,
            clips = clips,
            mediaLibrary = mediaLibrary
        )
    }
}
