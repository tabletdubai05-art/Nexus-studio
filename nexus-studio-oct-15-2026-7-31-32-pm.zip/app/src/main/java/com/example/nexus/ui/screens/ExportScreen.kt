package com.example.nexus.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexus.export.ExportState
import com.example.nexus.model.AspectRatio
import com.example.nexus.model.ExportResolution
import com.example.nexus.model.Project
import com.example.nexus.player.PlaybackController
import com.example.nexus.viewmodel.EditorViewModel
import com.example.ui.theme.*

@Composable
fun ExportScreen(
    viewModel: EditorViewModel,
    project: Project,
    onDismiss: () -> Unit
) {
    BackHandler { onDismiss() }

    var selectedResolution by remember { mutableStateOf(ExportResolution.FHD_1080P) }
    var selectedFps by remember { mutableStateOf(30) }
    val exportState by viewModel.exportState.collectAsState()
    val (outW, outH) = selectedResolution.getDimensions(project.config.aspectRatio)

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NexusSurface)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = NexusCyanLight)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Exportar Projeto",
                        color = NexusTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .background(NexusCyan.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "1080p Engine",
                        color = NexusCyanGlow,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        containerColor = NexusDarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Project Info Summary Card
            Card(
                colors = CardDefaults.cardColors(containerColor = NexusSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NexusBorder, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(project.name, color = NexusTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Duração", fontSize = 11.sp, color = NexusTextSecondary)
                            Text(PlaybackController.formatTimecode(project.totalDurationMs), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NexusCyanLight)
                        }
                        Column {
                            Text("Proporção", fontSize = 11.sp, color = NexusTextSecondary)
                            Text(project.config.aspectRatio.displayName, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NexusElectricPurpleLight)
                        }
                        Column {
                            Text("Camadas Ativas", fontSize = 11.sp, color = NexusTextSecondary)
                            Text("${project.clips.size} clipes", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NexusAmber)
                        }
                    }
                }
            }

            // Output Resolution Selector
            Text("Resolução de Saída", color = NexusTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ExportResolution.values().forEach { res ->
                    val isSelected = res == selectedResolution
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) NexusElectricPurple.copy(alpha = 0.25f) else NexusSurface
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) NexusCyanGlow else NexusBorder,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { selectedResolution = res }
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = res.label.takeWhile { it != ' ' },
                                color = if (isSelected) NexusCyanLight else NexusTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (res == ExportResolution.FHD_1080P) "1080×1920" else if (res == ExportResolution.HD_720P) "720×1280" else "4K UHD",
                                color = NexusTextMuted,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }

            // Framerate Selector
            Text("Taxa de Quadros (FPS)", color = NexusTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(24, 30, 60).forEach { fps ->
                    val isSelected = fps == selectedFps
                    FilledTonalButton(
                        onClick = { selectedFps = fps },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (isSelected) NexusCyan.copy(alpha = 0.25f) else NexusSurface,
                            contentColor = if (isSelected) NexusCyanLight else NexusTextSecondary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("$fps FPS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // Export Actions (Snapshot & Sequence)
            Text("Ações de Renderização", color = NexusTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)

            // Button 1: Immediate 1080p Frame Snapshot
            OutlinedButton(
                onClick = { viewModel.exportCurrentFrameSnapshot() },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = NexusCyanLight),
                border = androidx.compose.foundation.BorderStroke(1.dp, NexusCyan),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("export_snapshot_button")
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = "Capturar Quadro", modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Exportar Quadro Atual em 1080p (PNG)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            // Button 2: Video Project Export
            Button(
                onClick = { viewModel.startVideoExport(selectedFps, selectedResolution) },
                colors = ButtonDefaults.buttonColors(containerColor = NexusElectricPurple),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("start_video_export_button")
            ) {
                Icon(Icons.Default.MovieCreation, contentDescription = "Exportar Vídeo", modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Renderizar Vídeo em 1080p (MP4/Sequência)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }

            // Progress State or Success Card
            when (val state = exportState) {
                is ExportState.Progress -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NexusSurface),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, NexusCyan, RoundedCornerShape(10.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(state.currentTask, color = NexusCyanLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            LinearProgressIndicator(
                                progress = { state.progressPercent },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = NexusCyanGlow,
                                trackColor = NexusSurfaceCard
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Quadro ${state.currentFrame} de ${state.totalFrames}", color = NexusTextSecondary, fontSize = 10.sp)
                                Text("${(state.progressPercent * 100).toInt()}%", color = NexusCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                is ExportState.Success -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NexusGreen.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, NexusGreen, RoundedCornerShape(10.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Sucesso", tint = NexusGreen, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Renderização Concluída com Sucesso!", color = NexusGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                text = if (state.isFrameSnapshot) "Quadro renderizado em resolução total ${outW}x${outH} px."
                                else "Vídeo processado (${state.frameCount} quadros compostos a $selectedFps fps).",
                                color = NexusTextPrimary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "Arquivo: ${state.outputFilePath.substringAfterLast("/")}",
                                color = NexusTextSecondary,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
                is ExportState.Error -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NexusRedCut.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, NexusRedCut, RoundedCornerShape(10.dp))
                    ) {
                        Text(state.message, color = NexusRedCut, fontSize = 11.sp, modifier = Modifier.padding(12.dp))
                    }
                }
                ExportState.Idle -> {}
            }

            // Transparent Architecture & Roadmap Section (Item 6 compliance)
            Card(
                colors = CardDefaults.cardColors(containerColor = NexusSurfaceCard),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, NexusBorderHighlight, RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = "Arquitetura", tint = NexusCyanLight, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Diagnóstico Técnico do Motor NEXUS v0.1", color = NexusCyanLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "• Camadas e Transforms: O motor compõe posições (X, Y), escala, rotação e opacidade de textos e stickers diretamente em Canvas nativo 1080p.\n" +
                               "• Sincronia de Timeline: Suporta corte em playhead, trim de início/fim e mixagem de volume por clipe.\n" +
                               "• Codificação MP4 de Hardware: A codificação final em MP4 em celulares Android requer o pipeline NDK/MediaCodec + MediaMuxer (previsto para a v0.2). A v0.1 entrega a estrutura completa de renderização de quadros e serialização de projeto.",
                        color = NexusTextSecondary,
                        fontSize = 10.sp,
                        lineHeight = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
