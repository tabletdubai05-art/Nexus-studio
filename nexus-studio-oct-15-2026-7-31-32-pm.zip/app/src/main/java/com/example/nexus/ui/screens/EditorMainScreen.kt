package com.example.nexus.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexus.model.*
import com.example.nexus.ui.components.InspectorPanel
import com.example.nexus.ui.components.TimelineView
import com.example.nexus.ui.components.VideoPreview
import com.example.nexus.viewmodel.ActiveScreen
import com.example.nexus.viewmodel.EditorViewModel
import com.example.ui.theme.*

@Composable
fun EditorMainScreen(
    viewModel: EditorViewModel
) {
    val activeScreen by viewModel.activeScreen.collectAsState()
    val project by viewModel.currentProject.collectAsState()
    val selectedClipId by viewModel.selectedClipId.collectAsState()
    val currentPositionMs by viewModel.currentPositionMs.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val timelineZoom by viewModel.timelineZoom.collectAsState()
    val isSnapEnabled by viewModel.isSnapEnabled.collectAsState()
    val activeInspectorTab by viewModel.activeInspectorTab.collectAsState()
    val feedbackMessage by viewModel.feedbackMessage.collectAsState()
    val projectsList by viewModel.projectsList.collectAsState()

    var showMediaImportDialog by remember { mutableStateOf(false) }

    // Media Pickers
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { viewModel.importMedia(it, isVideo = true) }
    }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { viewModel.importMedia(it, isVideo = false) }
    }

    // Snackbar Host State
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(feedbackMessage) {
        feedbackMessage?.let {
            snackbarHostState.showSnackbar(it, duration = SnackbarDuration.Short)
            viewModel.clearFeedback()
        }
    }

    when (activeScreen) {
        ActiveScreen.HOME -> {
            HomeScreen(
                viewModel = viewModel,
                projects = projectsList,
                onOpenProject = { viewModel.openProject(it) }
            )
        }
        ActiveScreen.EXPORT_MODAL -> {
            ExportScreen(
                viewModel = viewModel,
                project = project,
                onDismiss = { viewModel.dismissExportModal() }
            )
        }
        ActiveScreen.EDITOR -> {
            androidx.activity.compose.BackHandler {
                viewModel.openHomeScreen()
            }

            Scaffold(
                topBar = {
                    StudioTopAppBar(
                        project = project,
                        onOpenProjects = { viewModel.openHomeScreen() },
                        onSaveProject = { viewModel.saveCurrentProject() },
                        onOpenExport = { viewModel.openExportModal() }
                    )
                },
                snackbarHost = {
                    SnackbarHost(
                        hostState = snackbarHostState,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                },
                containerColor = NexusDarkBg
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .navigationBarsPadding()
                ) {
                    // Central Video Preview Area
                    VideoPreview(
                        project = project,
                        currentPositionMs = currentPositionMs,
                        isPlaying = isPlaying,
                        selectedClipId = selectedClipId,
                        onTogglePlayPause = { viewModel.togglePlayPause() },
                        onStepFrame = { viewModel.stepFrame(it) },
                        onSelectClip = { viewModel.selectClip(it) },
                        onUpdateTransform = { clipId, tr -> viewModel.updateTransform(clipId, tr) },
                        modifier = Modifier.weight(1f)
                    )

                    // Inspector Panel (Shown when a clip is selected)
                    val selectedClip = remember(project.clips, selectedClipId) {
                        project.clips.find { it.id == selectedClipId }
                    }

                    if (selectedClip != null) {
                        InspectorPanel(
                            selectedClip = selectedClip,
                            activeTab = activeInspectorTab,
                            onTabSelected = { viewModel.setInspectorTab(it) },
                            onUpdateTransform = { viewModel.updateTransform(selectedClip.id, it) },
                            onUpdateTextProperties = { viewModel.updateTextProperties(selectedClip.id, it) },
                            onUpdateVolume = { vol, mute -> viewModel.updateVolume(selectedClip.id, vol, mute) },
                            onUpdateClipTrim = { sIn, sOut -> viewModel.updateClipTrim(selectedClip.id, sIn, sOut) },
                            onCloseInspector = { viewModel.selectClip(null) }
                        )
                    }

                    // Multi-track Timeline View
                    TimelineView(
                        project = project,
                        currentPositionMs = currentPositionMs,
                        selectedClipId = selectedClipId,
                        timelineZoom = timelineZoom,
                        isSnapEnabled = isSnapEnabled,
                        onSelectClip = { viewModel.selectClip(it) },
                        onSeekTo = { viewModel.seekTo(it) },
                        onUpdateClipTrim = { id, sIn, sOut -> viewModel.updateClipTrim(id, sIn, sOut) },
                        onUpdateClipStart = { id, start -> viewModel.updateClipTimelineStart(id, start) },
                        onSplitClip = { viewModel.splitClipAtPlayhead() },
                        onDuplicateClip = { viewModel.duplicateSelectedClip() },
                        onDeleteClip = { viewModel.deleteSelectedClip() },
                        onAddTextLayer = { viewModel.addTextLayer() },
                        onAddSticker = { showMediaImportDialog = true },
                        onImportMediaClick = { showMediaImportDialog = true },
                        onToggleSnap = { viewModel.toggleSnap() },
                        onZoomChange = { viewModel.setTimelineZoom(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (selectedClip != null) 190.dp else 260.dp)
                    )
                }
            }
        }
    }

    if (showMediaImportDialog) {
        MediaImportChooserDialog(
            onDismiss = { showMediaImportDialog = false },
            onPickVideo = {
                showMediaImportDialog = false
                videoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                )
            },
            onPickImage = {
                showMediaImportDialog = false
                imagePickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onAddGraphicBadge = { title, hex ->
                showMediaImportDialog = false
                viewModel.addStickerOverlay(title, hex)
            },
            onAddText = {
                showMediaImportDialog = false
                viewModel.addTextLayer()
            }
        )
    }
}

@Composable
fun StudioTopAppBar(
    project: Project,
    onOpenProjects: () -> Unit,
    onSaveProject: () -> Unit,
    onOpenExport: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NexusSurface)
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: Projects Button & Project Title
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledTonalIconButton(
                onClick = onOpenProjects,
                colors = IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = NexusSurfaceCard,
                    contentColor = NexusCyanLight
                ),
                modifier = Modifier
                    .size(36.dp)
                    .testTag("projects_drawer_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Voltar ao Início",
                    modifier = Modifier.size(18.dp)
                )
            }

            Column {
                Text(
                    text = project.name,
                    color = NexusTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    text = "${project.config.aspectRatio.label} • 1080p",
                    color = NexusCyanLight,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Right: Save & Export Buttons
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilledTonalIconButton(
                onClick = onSaveProject,
                colors = IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = NexusSurfaceCard,
                    contentColor = NexusTextSecondary
                ),
                modifier = Modifier
                    .size(36.dp)
                    .testTag("save_project_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Save,
                    contentDescription = "Salvar Projeto",
                    modifier = Modifier.size(18.dp)
                )
            }

            Button(
                onClick = onOpenExport,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NexusCyan
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(34.dp)
                    .testTag("header_export_button")
            ) {
                Icon(
                    imageVector = Icons.Default.FileDownload,
                    contentDescription = "Exportar",
                    tint = Color.Black,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Exportar",
                    color = Color.Black,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun MediaImportChooserDialog(
    onDismiss: () -> Unit,
    onPickVideo: () -> Unit,
    onPickImage: () -> Unit,
    onAddGraphicBadge: (String, Long) -> Unit,
    onAddText: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Adicionar à Edição", color = NexusTextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Device Video
                Card(
                    colors = CardDefaults.cardColors(containerColor = NexusSurfaceCard),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NexusBorder, RoundedCornerShape(8.dp))
                        .clickable { onPickVideo() }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = "Vídeo", tint = NexusElectricPurpleLight)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Importar Vídeo do Celular", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NexusTextPrimary)
                            Text("MP4, MOV da galeria do dispositivo", fontSize = 10.sp, color = NexusTextMuted)
                        }
                    }
                }

                // Device Photo
                Card(
                    colors = CardDefaults.cardColors(containerColor = NexusSurfaceCard),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NexusBorder, RoundedCornerShape(8.dp))
                        .clickable { onPickImage() }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Image, contentDescription = "Foto", tint = NexusCyanLight)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Importar Foto ou Imagem", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NexusTextPrimary)
                            Text("PNG, JPG como camada de sobreposição", fontSize = 10.sp, color = NexusTextMuted)
                        }
                    }
                }

                // Add Text Layer
                Card(
                    colors = CardDefaults.cardColors(containerColor = NexusSurfaceCard),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NexusBorder, RoundedCornerShape(8.dp))
                        .clickable { onAddText() }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.TextFields, contentDescription = "Texto", tint = NexusAmber)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Adicionar Título ou Legenda", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NexusTextPrimary)
                            Text("Camada tipográfica animável", fontSize = 10.sp, color = NexusTextMuted)
                        }
                    }
                }

                // Presets
                Text("Badges Gráficos NEXUS:", fontSize = 11.sp, color = NexusTextSecondary, modifier = Modifier.padding(top = 4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { onAddGraphicBadge("4K ULTRA", 0xFF059669) },
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("Badge 4K", fontSize = 9.sp, color = NexusGreen)
                    }

                    OutlinedButton(
                        onClick = { onAddGraphicBadge("PRO REC", 0xFFEF4444) },
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("Badge REC", fontSize = 9.sp, color = NexusRedCut)
                    }

                    OutlinedButton(
                        onClick = { onAddGraphicBadge("VFX NEON", 0xFF7C3AED) },
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("Neon VFX", fontSize = 9.sp, color = NexusElectricPurpleLight)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Fechar", color = NexusTextSecondary)
            }
        },
        containerColor = NexusSurface,
        shape = RoundedCornerShape(14.dp)
    )
}
