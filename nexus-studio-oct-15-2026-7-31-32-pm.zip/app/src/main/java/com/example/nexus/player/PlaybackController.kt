package com.example.nexus.player

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import com.example.nexus.model.Clip
import com.example.nexus.model.ClipType
import com.example.nexus.model.Project
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

class PlaybackController(private val context: Context) {

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private var scope: CoroutineScope? = null
    private var playbackJob: Job? = null

    private var activeMediaPlayer: MediaPlayer? = null
    private var currentlyLoadedUri: String? = null

    fun setScope(coroutineScope: CoroutineScope) {
        scope = coroutineScope
    }

    fun play(project: Project) {
        if (_isPlaying.value) return
        _isPlaying.value = true

        playbackJob?.cancel()
        playbackJob = scope?.launch(Dispatchers.Default) {
            val frameIntervalMs = 33L // ~30 FPS
            while (isActive && _isPlaying.value) {
                delay(frameIntervalMs)
                val newPos = _currentPositionMs.value + frameIntervalMs
                if (newPos >= project.totalDurationMs) {
                    _currentPositionMs.value = 0L
                    withContext(Dispatchers.Main) {
                        pause()
                    }
                    break
                } else {
                    _currentPositionMs.value = newPos
                }
            }
        }
    }

    fun pause() {
        _isPlaying.value = false
        playbackJob?.cancel()
        playbackJob = null
        try {
            if (activeMediaPlayer?.isPlaying == true) {
                activeMediaPlayer?.pause()
            }
        } catch (_: Exception) {}
    }

    fun togglePlayPause(project: Project) {
        if (_isPlaying.value) {
            pause()
        } else {
            if (_currentPositionMs.value >= project.totalDurationMs) {
                seekTo(0L)
            }
            play(project)
        }
    }

    fun seekTo(positionMs: Long) {
        _currentPositionMs.value = positionMs.coerceAtLeast(0L)
        try {
            activeMediaPlayer?.let { player ->
                player.seekTo(positionMs.toInt())
            }
        } catch (_: Exception) {}
    }

    fun stepFrames(frames: Int, fps: Int = 30) {
        val deltaMs = (1000L / fps) * frames
        val newPos = (_currentPositionMs.value + deltaMs).coerceAtLeast(0L)
        seekTo(newPos)
    }

    fun release() {
        pause()
        try {
            activeMediaPlayer?.release()
            activeMediaPlayer = null
        } catch (_: Exception) {}
    }

    companion object {
        fun formatTimecode(ms: Long): String {
            val totalSeconds = ms / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            val hundredths = (ms % 1000) / 10
            return String.format("%02d:%02d.%02d", minutes, seconds, hundredths)
        }

        fun formatSeconds(ms: Long): String {
            val totalSeconds = (ms + 500) / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return String.format("%02d:%02d", minutes, seconds)
        }
    }
}
