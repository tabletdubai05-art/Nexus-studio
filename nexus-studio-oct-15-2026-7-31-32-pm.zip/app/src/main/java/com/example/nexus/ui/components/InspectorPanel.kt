package com.example.nexus.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexus.model.*
import com.example.nexus.player.PlaybackController
import com.example.nexus.viewmodel.InspectorTab
import com.example.ui.theme.*

@Composable
fun InspectorPanel(
    selectedClip: Clip?,
    activeTab: InspectorTab,
    onTabSelected: (InspectorTab) -> Unit,
    onUpdateTransform: (TransformProperties) -> Unit,
    onUpdateTextProperties: (TextProperties) -> Unit,
    onUpdateVolume: (Float, Boolean) -> Unit,
    onUpdateClipTrim: (Long, Long) -> Unit,
    onCloseInspector: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (selectedClip == null) return

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(max = 240.dp)
            .background(NexusSurfaceCard)
            .border(1.dp, NexusBorderHighlight, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("inspector_panel")
    ) {
        // Header with Title and Tab selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(Color(selectedClip.colorBadgeHex), CircleShape)
                )
                Text(
                    text = selectedClip.title,
                    color = NexusTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    text = "• ${selectedClip.trackType.displayName}",
                    color = NexusTextMuted,
                    fontSize = 10.sp
                )
            }

            IconButton(
                onClick = onCloseInspector,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Fechar Painel",
                    tint = NexusTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Tab Row
        ScrollableTabRow(
            selectedTabIndex = activeTab.ordinal,
            containerColor = Color.Transparent,
            contentColor = NexusCyanLight,
            divider = {},
            edgePadding = 0.dp,
            modifier = Modifier.height(34.dp)
        ) {
            Tab(
                selected = activeTab == InspectorTab.TRANSFORM,
                onClick = { onTabSelected(InspectorTab.TRANSFORM) },
                text = { Text("TRANSFORM", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            )

            if (selectedClip.type == ClipType.TEXT) {
                Tab(
                    selected = activeTab == InspectorTab.TEXT,
                    onClick = { onTabSelected(InspectorTab.TEXT) },
                    text = { Text("TEXTO", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                )
            }

            Tab(
                selected = activeTab == InspectorTab.AUDIO,
                onClick = { onTabSelected(InspectorTab.AUDIO) },
                text = { Text("ÁUDIO", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            )

            Tab(
                selected = activeTab == InspectorTab.TIMING,
                onClick = { onTabSelected(InspectorTab.TIMING) },
                text = { Text("TEMPO", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            )
        }

        Divider(color = NexusBorder, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 4.dp))

        // Tab Content
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(scrollState)
        ) {
            when (activeTab) {
                InspectorTab.TRANSFORM -> TransformInspectorTab(
                    transform = selectedClip.transform,
                    onUpdateTransform = onUpdateTransform
                )
                InspectorTab.TEXT -> TextInspectorTab(
                    textProps = selectedClip.textProperties,
                    onUpdateTextProps = onUpdateTextProperties
                )
                InspectorTab.AUDIO -> AudioInspectorTab(
                    volume = selectedClip.volume,
                    isMuted = selectedClip.isMuted,
                    onUpdateVolume = onUpdateVolume
                )
                InspectorTab.TIMING -> TimingInspectorTab(
                    clip = selectedClip,
                    onUpdateTrim = onUpdateClipTrim
                )
            }
        }
    }
}

@Composable
fun TransformInspectorTab(
    transform: TransformProperties,
    onUpdateTransform: (TransformProperties) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Quick Actions Row: Center, Reset
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { onUpdateTransform(transform.copy(positionX = 0f, positionY = 0f)) },
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Text("Centralizar", fontSize = 10.sp, color = NexusCyanLight)
            }

            OutlinedButton(
                onClick = { onUpdateTransform(TransformProperties()) },
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Text("Redefinir Tudo", fontSize = 10.sp, color = NexusTextSecondary)
            }
        }

        // Position X & Position Y
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Posição X: ${transform.positionX.toInt()}%", fontSize = 10.sp, color = NexusTextSecondary)
                Slider(
                    value = transform.positionX,
                    onValueChange = { onUpdateTransform(transform.copy(positionX = it)) },
                    valueRange = -100f..100f,
                    colors = SliderDefaults.colors(thumbColor = NexusCyanLight, activeTrackColor = NexusCyan)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Posição Y: ${transform.positionY.toInt()}%", fontSize = 10.sp, color = NexusTextSecondary)
                Slider(
                    value = transform.positionY,
                    onValueChange = { onUpdateTransform(transform.copy(positionY = it)) },
                    valueRange = -100f..100f,
                    colors = SliderDefaults.colors(thumbColor = NexusCyanLight, activeTrackColor = NexusCyan)
                )
            }
        }

        // Scale & Rotation
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Escala: ${(transform.scale * 100).toInt()}%", fontSize = 10.sp, color = NexusTextSecondary)
                Slider(
                    value = transform.scale,
                    onValueChange = { onUpdateTransform(transform.copy(scale = it)) },
                    valueRange = 0.2f..3.0f,
                    colors = SliderDefaults.colors(thumbColor = NexusElectricPurpleLight, activeTrackColor = NexusElectricPurple)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Rotação: ${transform.rotation.toInt()}°", fontSize = 10.sp, color = NexusTextSecondary)
                Slider(
                    value = transform.rotation,
                    onValueChange = { onUpdateTransform(transform.copy(rotation = it)) },
                    valueRange = -180f..180f,
                    colors = SliderDefaults.colors(thumbColor = NexusElectricPurpleLight, activeTrackColor = NexusElectricPurple)
                )
            }
        }

        // Opacity
        Column(modifier = Modifier.fillMaxWidth()) {
            Text("Opacidade: ${(transform.opacity * 100).toInt()}%", fontSize = 10.sp, color = NexusTextSecondary)
            Slider(
                value = transform.opacity,
                onValueChange = { onUpdateTransform(transform.copy(opacity = it)) },
                valueRange = 0.0f..1.0f,
                colors = SliderDefaults.colors(thumbColor = NexusAmber, activeTrackColor = NexusAmber)
            )
        }
    }
}

@Composable
fun TextInspectorTab(
    textProps: TextProperties,
    onUpdateTextProps: (TextProperties) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Text Input
        OutlinedTextField(
            value = textProps.text,
            onValueChange = { onUpdateTextProps(textProps.copy(text = it)) },
            label = { Text("Texto da Camada", fontSize = 10.sp) },
            singleLine = false,
            maxLines = 2,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NexusCyanGlow,
                unfocusedBorderColor = NexusBorderHighlight,
                focusedTextColor = NexusTextPrimary,
                unfocusedTextColor = NexusTextPrimary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("text_input_field")
        )

        // Font Size Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Tamanho: ${textProps.fontSizeSp.toInt()}sp", fontSize = 10.sp, color = NexusTextSecondary)
            Slider(
                value = textProps.fontSizeSp,
                onValueChange = { onUpdateTextProps(textProps.copy(fontSizeSp = it)) },
                valueRange = 12f..60f,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = NexusCyanLight, activeTrackColor = NexusCyan)
            )
        }

        // Quick Color Palette
        val colorPresets = listOf(
            Pair("Cyan", 0xFF00F0FF),
            Pair("Roxo", 0xFFA78BFA),
            Pair("Branco", 0xFFFFFFFF),
            Pair("Amarelo", 0xFFFCD34D),
            Pair("Rosa", 0xFFF472B6),
            Pair("Verde", 0xFF34D399)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Cor:", fontSize = 10.sp, color = NexusTextSecondary)
            colorPresets.forEach { (name, hex) ->
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .background(Color(hex), CircleShape)
                        .border(
                            width = if (textProps.textColorHex == hex) 2.dp else 0.5.dp,
                            color = if (textProps.textColorHex == hex) Color.White else NexusBorder,
                            shape = CircleShape
                        )
                        .clickable {
                            onUpdateTextProps(textProps.copy(textColorHex = hex))
                        }
                )
            }
        }

        // Formatting Toggles: Pill Background & Bold
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = textProps.hasBackgroundPill,
                    onCheckedChange = { onUpdateTextProps(textProps.copy(hasBackgroundPill = it)) },
                    colors = CheckboxDefaults.colors(checkedColor = NexusCyan)
                )
                Text("Fundo Tarja", fontSize = 10.sp, color = NexusTextPrimary)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = textProps.isBold,
                    onCheckedChange = { onUpdateTextProps(textProps.copy(isBold = it)) },
                    colors = CheckboxDefaults.colors(checkedColor = NexusElectricPurple)
                )
                Text("Negrito", fontSize = 10.sp, color = NexusTextPrimary)
            }
        }
    }
}

@Composable
fun AudioInspectorTab(
    volume: Float,
    isMuted: Boolean,
    onUpdateVolume: (Float, Boolean) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Volume: ${(volume * 100).toInt()}%",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = NexusTextPrimary
            )

            FilledTonalButton(
                onClick = { onUpdateVolume(volume, !isMuted) },
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = if (isMuted) NexusRedCut.copy(alpha = 0.2f) else NexusSurface,
                    contentColor = if (isMuted) NexusRedCut else NexusCyanLight
                ),
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Icon(
                    imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                    contentDescription = "Mudo",
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isMuted) "Mutado" else "Ativo", fontSize = 10.sp)
            }
        }

        Slider(
            value = if (isMuted) 0f else volume,
            onValueChange = { onUpdateVolume(it, false) },
            valueRange = 0.0f..2.0f,
            colors = SliderDefaults.colors(thumbColor = NexusCyanLight, activeTrackColor = NexusCyan),
            modifier = Modifier.testTag("volume_slider")
        )

        Text(
            text = "Amplificação de até 200% para diálogos com volume baixo.",
            fontSize = 9.sp,
            color = NexusTextMuted
        )
    }
}

@Composable
fun TimingInspectorTab(
    clip: Clip,
    onUpdateTrim: (Long, Long) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Início (Trim In):", fontSize = 10.sp, color = NexusTextSecondary)
                Text(PlaybackController.formatTimecode(clip.sourceInMs), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NexusCyanLight)
            }
            Column {
                Text("Fim (Trim Out):", fontSize = 10.sp, color = NexusTextSecondary)
                Text(PlaybackController.formatTimecode(clip.sourceOutMs), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NexusCyanLight)
            }
            Column {
                Text("Duração Total:", fontSize = 10.sp, color = NexusTextSecondary)
                Text(PlaybackController.formatTimecode(clip.durationMs), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NexusTextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Frame Nudge Buttons
        Text("Ajuste Fino por Quadros:", fontSize = 10.sp, color = NexusTextMuted)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { onUpdateTrim((clip.sourceInMs - 33L).coerceAtLeast(0L), clip.sourceOutMs) },
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(28.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("-1 Qdr", fontSize = 9.sp)
            }

            OutlinedButton(
                onClick = { onUpdateTrim(clip.sourceInMs + 33L, clip.sourceOutMs) },
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(28.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("+1 Qdr", fontSize = 9.sp)
            }

            OutlinedButton(
                onClick = { onUpdateTrim(clip.sourceInMs, (clip.sourceOutMs - 33L).coerceAtLeast(clip.sourceInMs + 100L)) },
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(28.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("-1 Fim", fontSize = 9.sp)
            }

            OutlinedButton(
                onClick = { onUpdateTrim(clip.sourceInMs, clip.sourceOutMs + 33L) },
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(28.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("+1 Fim", fontSize = 9.sp)
            }
        }
    }
}
