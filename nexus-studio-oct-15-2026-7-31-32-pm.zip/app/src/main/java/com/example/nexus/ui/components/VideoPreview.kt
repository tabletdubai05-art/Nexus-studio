package com.example.nexus.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexus.model.*
import com.example.nexus.player.PlaybackController
import com.example.ui.theme.*

@Composable
fun VideoPreview(
    project: Project,
    currentPositionMs: Long,
    isPlaying: Boolean,
    selectedClipId: String?,
    onTogglePlayPause: () -> Unit,
    onStepFrame: (Boolean) -> Unit,
    onSelectClip: (String?) -> Unit,
    onUpdateTransform: (String, TransformProperties) -> Unit,
    modifier: Modifier = Modifier
) {
    val aspectRatio = project.config.aspectRatio
    val activeClips = remember(project.clips, currentPositionMs) {
        project.clips.filter { it.containsTime(currentPositionMs) }
    }

    val activeVideo = activeClips.firstOrNull { it.trackType == TrackType.VIDEO }
    val activeOverlays = activeClips.filter { it.trackType == TrackType.OVERLAY }
    val activeTexts = activeClips.filter { it.trackType == TrackType.TEXT }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(NexusDarkBg)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        // Aspect ratio container (calculated based on available space)
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            contentAlignment = Alignment.Center
        ) {
            val maxAvailableWidth = maxWidth
            val maxAvailableHeight = 270.dp

            val targetRatio = aspectRatio.widthRatio / aspectRatio.heightRatio
            val (boxWidth, boxHeight) = if (targetRatio < 1f) {
                // Vertical (e.g., 9:16)
                val h = maxAvailableHeight
                val w = (h.value * targetRatio).dp.coerceAtMost(maxAvailableWidth)
                Pair(w, h)
            } else {
                // Landscape / Square
                val w = maxAvailableWidth.coerceAtMost(380.dp)
                val h = (w.value / targetRatio).dp.coerceAtMost(maxAvailableHeight)
                Pair(w, h)
            }

            // Canvas & Layer Area
            Box(
                modifier = Modifier
                    .size(width = boxWidth, height = boxHeight)
                    .clip(RoundedCornerShape(8.dp))
                    .background(NexusSurface)
                    .border(1.5.dp, NexusBorderHighlight, RoundedCornerShape(8.dp))
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = {
                                // Tap outside to deselect
                                onSelectClip(null)
                            }
                        )
                    }
                    .testTag("video_preview_canvas"),
                contentAlignment = Alignment.Center
            ) {
                // 1. Video background simulation / live feed
                if (activeVideo != null) {
                    val localMs = activeVideo.getLocalTimeMs(currentPositionMs)
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(activeVideo.colorBadgeHex).copy(alpha = 0.4f),
                                        Color(0xFF0F1117),
                                        Color(activeVideo.colorBadgeHex).copy(alpha = 0.25f)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = "Vídeo Ativo",
                                tint = NexusCyanLight.copy(alpha = 0.8f),
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = activeVideo.title,
                                color = NexusTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "TC: ${PlaybackController.formatTimecode(localMs)}",
                                color = NexusCyan,
                                fontSize = 10.sp
                            )
                        }
                    }
                } else {
                    // Empty state in timeline
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VideoCall,
                            contentDescription = "Sem vídeo",
                            tint = NexusTextMuted,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Nenhum clipe neste ponto",
                            color = NexusTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                // 2. Overlays & Image Layers
                activeOverlays.forEach { overlay ->
                    val isSelected = overlay.id == selectedClipId
                    OverlayLayerItem(
                        clip = overlay,
                        isSelected = isSelected,
                        containerWidthDp = boxWidth.value,
                        containerHeightDp = boxHeight.value,
                        onSelect = { onSelectClip(overlay.id) },
                        onTransformChanged = { newTransform ->
                            onUpdateTransform(overlay.id, newTransform)
                        }
                    )
                }

                // 3. Text Layers
                activeTexts.forEach { textClip ->
                    val isSelected = textClip.id == selectedClipId
                    TextLayerItem(
                        clip = textClip,
                        isSelected = isSelected,
                        containerWidthDp = boxWidth.value,
                        containerHeightDp = boxHeight.value,
                        onSelect = { onSelectClip(textClip.id) },
                        onTransformChanged = { newTransform ->
                            onUpdateTransform(textClip.id, newTransform)
                        }
                    )
                }

                // Subtle Studio Safe Area Grid
                StudioGridGuides(aspectRatio = aspectRatio)

                // Aspect ratio badge (top-left)
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .background(Color(0x99000000), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${aspectRatio.label} • 1080p",
                        color = NexusCyanLight,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Overlay Playback Controls (Floating bottom pill on preview)
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = 12.dp)
                .background(Color(0xEE13151B), RoundedCornerShape(20.dp))
                .border(1.dp, NexusBorderHighlight, RoundedCornerShape(20.dp))
                .padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Previous Frame
            IconButton(
                onClick = { onStepFrame(false) },
                modifier = Modifier
                    .size(34.dp)
                    .testTag("prev_frame_button")
            ) {
                Icon(
                    imageVector = Icons.Default.SkipPrevious,
                    contentDescription = "Quadro Anterior",
                    tint = NexusTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Play / Pause Primary Button
            Button(
                onClick = onTogglePlayPause,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isPlaying) NexusAmber else NexusElectricPurple
                ),
                shape = CircleShape,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier
                    .size(36.dp)
                    .testTag("play_pause_button")
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pausar" else "Reproduzir",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Next Frame
            IconButton(
                onClick = { onStepFrame(true) },
                modifier = Modifier
                    .size(34.dp)
                    .testTag("next_frame_button")
            ) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Próximo Quadro",
                    tint = NexusTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Timecode display
            Text(
                text = "${PlaybackController.formatTimecode(currentPositionMs)} / ${PlaybackController.formatSeconds(project.totalDurationMs)}",
                color = NexusCyanLight,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp, end = 6.dp)
            )
        }
    }
}

@Composable
fun TextLayerItem(
    clip: Clip,
    isSelected: Boolean,
    containerWidthDp: Float,
    containerHeightDp: Float,
    onSelect: () -> Unit,
    onTransformChanged: (TransformProperties) -> Unit
) {
    val tProps = clip.textProperties
    val transform = clip.transform

    val offsetX = (transform.positionX / 100f) * (containerWidthDp / 2f)
    val offsetY = (transform.positionY / 100f) * (containerHeightDp / 2f)

    Box(
        modifier = Modifier
            .offset(x = offsetX.dp, y = offsetY.dp)
            .graphicsLayer {
                scaleX = transform.scale
                scaleY = transform.scale
                rotationZ = transform.rotation
                alpha = transform.opacity
            }
            .pointerInput(clip.id) {
                detectTapGestures {
                    onSelect()
                }
            }
            .pointerInput(clip.id) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    val deltaXPercent = (dragAmount.x / (containerWidthDp / 2f)) * 100f
                    val deltaYPercent = (dragAmount.y / (containerHeightDp / 2f)) * 100f
                    val newX = (transform.positionX + deltaXPercent).coerceIn(-100f, 100f)
                    val newY = (transform.positionY + deltaYPercent).coerceIn(-100f, 100f)
                    onTransformChanged(transform.copy(positionX = newX, positionY = newY))
                }
            }
            .then(
                if (isSelected) {
                    Modifier
                        .border(1.5.dp, NexusCyanGlow, RoundedCornerShape(6.dp))
                        .padding(4.dp)
                } else Modifier.padding(4.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        val bgModifier = if (tProps.hasBackgroundPill) {
            Modifier
                .background(Color(tProps.backgroundColorHex), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        } else Modifier

        Text(
            text = tProps.text,
            color = Color(tProps.textColorHex),
            fontSize = (tProps.fontSizeSp * 0.7f).sp,
            fontWeight = if (tProps.isBold) FontWeight.Bold else FontWeight.Normal,
            textAlign = TextAlign.Center,
            modifier = bgModifier
        )
    }
}

@Composable
fun OverlayLayerItem(
    clip: Clip,
    isSelected: Boolean,
    containerWidthDp: Float,
    containerHeightDp: Float,
    onSelect: () -> Unit,
    onTransformChanged: (TransformProperties) -> Unit
) {
    val transform = clip.transform

    val offsetX = (transform.positionX / 100f) * (containerWidthDp / 2f)
    val offsetY = (transform.positionY / 100f) * (containerHeightDp / 2f)

    Box(
        modifier = Modifier
            .offset(x = offsetX.dp, y = offsetY.dp)
            .graphicsLayer {
                scaleX = transform.scale
                scaleY = transform.scale
                rotationZ = transform.rotation
                alpha = transform.opacity
            }
            .pointerInput(clip.id) {
                detectTapGestures { onSelect() }
            }
            .pointerInput(clip.id) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    val deltaXPercent = (dragAmount.x / (containerWidthDp / 2f)) * 100f
                    val deltaYPercent = (dragAmount.y / (containerHeightDp / 2f)) * 100f
                    val newX = (transform.positionX + deltaXPercent).coerceIn(-100f, 100f)
                    val newY = (transform.positionY + deltaYPercent).coerceIn(-100f, 100f)
                    onTransformChanged(transform.copy(positionX = newX, positionY = newY))
                }
            }
            .then(
                if (isSelected) {
                    Modifier
                        .border(1.5.dp, NexusCyanGlow, RoundedCornerShape(8.dp))
                        .padding(2.dp)
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        // Aesthetic Badge Graphic
        Box(
            modifier = Modifier
                .size(48.dp)
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(clip.colorBadgeHex),
                            Color(clip.colorBadgeHex).copy(alpha = 0.6f)
                        )
                    ),
                    RoundedCornerShape(8.dp)
                )
                .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Layers,
                    contentDescription = clip.title,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = clip.title.take(6),
                    color = Color.White,
                    fontSize = 7.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun StudioGridGuides(aspectRatio: AspectRatio) {
    // Faint safe area border for reels/shorts UI elements
    if (aspectRatio == AspectRatio.VERTICAL_9_16) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 28.dp)
                .border(0.5.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
        )
    }
}
