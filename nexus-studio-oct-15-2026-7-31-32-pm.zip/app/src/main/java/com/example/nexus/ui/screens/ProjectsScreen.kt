package com.example.nexus.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexus.model.AspectRatio
import com.example.nexus.model.Project
import com.example.nexus.player.PlaybackController
import com.example.nexus.viewmodel.EditorViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProjectsScreen(
    viewModel: EditorViewModel,
    projects: List<Project>,
    currentProjectId: String,
    onOpenProject: (Project) -> Unit,
    onDismiss: () -> Unit
) {
    BackHandler { onDismiss() }

    var showNewProjectDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NexusSurface)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = NexusCyanLight)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Meus Projetos",
                        color = NexusTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = { showNewProjectDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = NexusElectricPurple),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("create_new_project_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Novo", modifier = Modifier.size(16.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Novo Projeto", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        },
        containerColor = NexusDarkBg
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            item {
                // Studio Header Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(NexusElectricPurpleDark, NexusSurfaceCard)
                            )
                        )
                        .border(1.dp, NexusBorderHighlight, RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("NEXUS STUDIO", color = NexusCyanGlow, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .background(NexusCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("v0.1", color = NexusCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            "Editor móvel profissional de vídeo com multi-camadas, transforms em tempo real e timeline precisa.",
                            color = NexusTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            items(projects, key = { it.id }) { project ->
                val isCurrent = project.id == currentProjectId
                ProjectItemCard(
                    project = project,
                    isCurrent = isCurrent,
                    onOpen = { onOpenProject(project) },
                    onDelete = { viewModel.deleteProject(project) }
                )
            }
        }
    }

    if (showNewProjectDialog) {
        NewProjectDialog(
            onDismiss = { showNewProjectDialog = false },
            onCreate = { name, ratio ->
                showNewProjectDialog = false
                viewModel.createNewProject(name, ratio)
            }
        )
    }
}

@Composable
fun ProjectItemCard(
    project: Project,
    isCurrent: Boolean,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }
    val formattedDate = remember(project.updatedAt) { dateFormat.format(Date(project.updatedAt)) }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrent) NexusSurfaceCard else NexusSurface
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isCurrent) 1.5.dp else 1.dp,
                color = if (isCurrent) NexusCyanGlow else NexusBorder,
                shape = RoundedCornerShape(12.dp)
            )
            .clip(RoundedCornerShape(12.dp))
            .clickable { onOpen() }
            .testTag("project_item_${project.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = project.name,
                        color = NexusTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (isCurrent) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .background(NexusCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("ABERTO", color = NexusCyanLight, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = project.config.aspectRatio.label,
                        color = NexusElectricPurpleLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text("•", color = NexusTextMuted, fontSize = 10.sp)
                    Text(
                        text = PlaybackController.formatSeconds(project.totalDurationMs),
                        color = NexusCyanLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text("•", color = NexusTextMuted, fontSize = 10.sp)
                    Text(
                        text = "${project.clips.size} clipes",
                        color = NexusTextSecondary,
                        fontSize = 11.sp
                    )
                }

                Text(
                    text = "Modificado: $formattedDate",
                    color = NexusTextMuted,
                    fontSize = 10.sp
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Excluir Projeto",
                    tint = NexusRedCut.copy(alpha = 0.8f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun NewProjectDialog(
    onDismiss: () -> Unit,
    onCreate: (String, AspectRatio) -> Unit
) {
    var projectName by remember { mutableStateOf("Meu Vídeo") }
    var selectedRatio by remember { mutableStateOf(AspectRatio.VERTICAL_9_16) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Novo Projeto NEXUS", color = NexusTextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = projectName,
                    onValueChange = { projectName = it },
                    label = { Text("Nome do Projeto") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NexusCyanGlow,
                        unfocusedBorderColor = NexusBorder,
                        focusedTextColor = NexusTextPrimary,
                        unfocusedTextColor = NexusTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("new_project_name_input")
                )

                Text("Proporção do Vídeo:", fontSize = 12.sp, color = NexusTextSecondary)

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    AspectRatio.values().take(3).forEach { ratio ->
                        val isSelected = ratio == selectedRatio
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) NexusElectricPurple.copy(alpha = 0.2f) else NexusSurface
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) NexusCyanLight else NexusBorder,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedRatio = ratio }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(ratio.displayName, fontSize = 12.sp, color = if (isSelected) NexusCyanLight else NexusTextPrimary, fontWeight = FontWeight.SemiBold)
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = "Selecionado", tint = NexusCyanLight, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onCreate(projectName, selectedRatio) },
                colors = ButtonDefaults.buttonColors(containerColor = NexusElectricPurple),
                modifier = Modifier.testTag("confirm_create_project_button")
            ) {
                Text("Criar Projeto", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = NexusTextSecondary)
            }
        },
        containerColor = NexusSurface,
        shape = RoundedCornerShape(14.dp)
    )
}
