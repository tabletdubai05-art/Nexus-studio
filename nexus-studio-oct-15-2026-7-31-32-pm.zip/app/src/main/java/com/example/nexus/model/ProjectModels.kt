package com.example.nexus.model

import java.util.UUID

enum class AspectRatio(val label: String, val widthRatio: Float, val heightRatio: Float, val displayName: String) {
    VERTICAL_9_16("9:16", 9f, 16f, "Reels / TikTok (9:16)"),
    LANDSCAPE_16_9("16:9", 16f, 9f, "YouTube / Vídeo (16:9)"),
    SQUARE_1_1("1:1", 1f, 1f, "Feed / Post (1:1)"),
    PORTRAIT_4_5("4:5", 4f, 5f, "Instagram Portrait (4:5)"),
    CINEMATIC_21_9("21:9", 21f, 9f, "Cinemático (21:9)");

    fun calculateDisplayHeight(containerWidth: Float): Float {
        return containerWidth * (heightRatio / widthRatio)
    }
}

enum class ExportResolution(val label: String, val width: Int, val height: Int, val description: String) {
    FHD_1080P("1080p (FHD)", 1080, 1920, "Recomendado para mídias sociais em alta qualidade"),
    HD_720P("720p (HD)", 720, 1280, "Exportação rápida com tamanho reduzido"),
    UHD_4K("4K (UHD)", 2160, 3840, "Máxima nitidez e detalhes profissionais");

    fun getDimensions(aspectRatio: AspectRatio): Pair<Int, Int> {
        val baseLong = 1920
        return when (aspectRatio) {
            AspectRatio.VERTICAL_9_16 -> Pair(1080, 1920)
            AspectRatio.LANDSCAPE_16_9 -> Pair(1920, 1080)
            AspectRatio.SQUARE_1_1 -> Pair(1080, 1080)
            AspectRatio.PORTRAIT_4_5 -> Pair(1080, 1350)
            AspectRatio.CINEMATIC_21_9 -> Pair(1920, 822)
        }
    }
}

enum class ClipType {
    VIDEO,
    IMAGE,
    TEXT,
    AUDIO
}

enum class TrackType(val displayName: String, val order: Int) {
    TEXT("Texto / Títulos", 0),
    OVERLAY("Sobreposição / Imagem", 1),
    VIDEO("Vídeo Principal", 2),
    AUDIO("Trilha de Áudio", 3)
}

data class TransformProperties(
    val positionX: Float = 0f,       // -100f to +100f % offset
    val positionY: Float = 0f,       // -100f to +100f % offset
    val scale: Float = 1.0f,         // 0.2f to 4.0f
    val rotation: Float = 0f,        // -180f to +180f
    val opacity: Float = 1.0f,       // 0.0f to 1.0f
    val isFlippedHorizontal: Boolean = false,
    val isFlippedVertical: Boolean = false
)

data class TextProperties(
    val text: String = "NEXUS TITLE",
    val textColorHex: Long = 0xFFFFFFFF,
    val fontSizeSp: Float = 24f,
    val backgroundColorHex: Long = 0xAA000000,
    val hasBackgroundPill: Boolean = true,
    val isBold: Boolean = true,
    val isItalic: Boolean = false,
    val alignment: Int = 1           // 0: Left, 1: Center, 2: Right
)

data class MediaItem(
    val id: String = UUID.randomUUID().toString(),
    val uriString: String,
    val name: String,
    val type: ClipType,
    val durationMs: Long = 5000L,
    val width: Int = 1080,
    val height: Int = 1920,
    val thumbnailUri: String? = null,
    val sampleColorHex: Long = 0xFF8B5CF6
)

data class Clip(
    val id: String = UUID.randomUUID().toString(),
    val mediaId: String? = null,
    val mediaUri: String? = null,
    val type: ClipType,
    val trackType: TrackType,
    val title: String,
    val timelineStartMs: Long,
    val sourceInMs: Long = 0L,
    val sourceOutMs: Long = 5000L,
    val volume: Float = 1.0f,
    val isMuted: Boolean = false,
    val transform: TransformProperties = TransformProperties(),
    val textProperties: TextProperties = TextProperties(),
    val colorBadgeHex: Long = 0xFF8B5CF6
) {
    val durationMs: Long
        get() = (sourceOutMs - sourceInMs).coerceAtLeast(100L)

    val timelineEndMs: Long
        get() = timelineStartMs + durationMs

    fun containsTime(timeMs: Long): Boolean {
        return timeMs >= timelineStartMs && timeMs < timelineEndMs
    }

    fun getLocalTimeMs(timelineTimeMs: Long): Long {
        val offset = timelineTimeMs - timelineStartMs
        return (sourceInMs + offset).coerceIn(sourceInMs, sourceOutMs)
    }
}

data class ProjectConfig(
    val aspectRatio: AspectRatio = AspectRatio.VERTICAL_9_16,
    val fps: Int = 30,
    val resolution: ExportResolution = ExportResolution.FHD_1080P,
    val defaultClipDurationMs: Long = 4000L
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Projeto Sem Título",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val config: ProjectConfig = ProjectConfig(),
    val clips: List<Clip> = emptyList(),
    val mediaLibrary: List<MediaItem> = emptyList()
) {
    val totalDurationMs: Long
        get() {
            if (clips.isEmpty()) return 10000L
            val maxEnd = clips.maxOfOrNull { it.timelineEndMs } ?: 0L
            return maxEnd.coerceAtLeast(3000L)
        }
}
