package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NEXUS Studio Core Palette: Graphite, Electric Purple, Neon Cyan
val NexusDarkBg = Color(0xFF0B0C10)
val NexusSurface = Color(0xFF13151B)
val NexusSurfaceCard = Color(0xFF1B1E28)
val NexusSurfaceTrack = Color(0xFF222634)
val NexusBorder = Color(0xFF2E3446)
val NexusBorderHighlight = Color(0xFF3F475F)

val NexusElectricPurple = Color(0xFF8B5CF6)
val NexusElectricPurpleDark = Color(0xFF6D28D9)
val NexusElectricPurpleLight = Color(0xFFA78BFA)
val NexusPurpleGlow = Color(0xFF7C3AED)

val NexusCyan = Color(0xFF06B6D4)
val NexusCyanLight = Color(0xFF22D3EE)
val NexusCyanGlow = Color(0xFF00F0FF)

val NexusTextPrimary = Color(0xFFF1F5F9)
val NexusTextSecondary = Color(0xFF94A3B8)
val NexusTextMuted = Color(0xFF64748B)

val NexusTrackVideo = Color(0xFF7C3AED)
val NexusTrackOverlay = Color(0xFF059669)
val NexusTrackText = Color(0xFFD97706)
val NexusTrackAudio = Color(0xFF0284C7)

val NexusRedCut = Color(0xFFEF4444)
val NexusAmber = Color(0xFFF59E0B)
val NexusGreen = Color(0xFF10B981)
