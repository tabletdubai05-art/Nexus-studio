package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NexusDarkColorScheme = darkColorScheme(
    primary = NexusElectricPurple,
    onPrimary = Color.White,
    primaryContainer = NexusElectricPurpleDark,
    onPrimaryContainer = Color.White,
    secondary = NexusCyan,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF0E4A56),
    onSecondaryContainer = NexusCyanLight,
    tertiary = NexusCyanGlow,
    onTertiary = Color.Black,
    background = NexusDarkBg,
    onBackground = NexusTextPrimary,
    surface = NexusSurface,
    onSurface = NexusTextPrimary,
    surfaceVariant = NexusSurfaceCard,
    onSurfaceVariant = NexusTextSecondary,
    outline = NexusBorder,
    outlineVariant = NexusBorderHighlight,
    error = NexusRedCut,
    onError = Color.White
)

@Composable
fun NexusStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NexusDarkColorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    NexusStudioTheme(content = content)
}
